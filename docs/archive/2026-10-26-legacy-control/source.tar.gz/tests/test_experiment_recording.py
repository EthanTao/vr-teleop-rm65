"""Local evidence and fake-hardware tests. No SSH, SDK or robot connections."""

from dataclasses import replace
import hashlib
import json
from pathlib import Path
import queue
import shlex
import subprocess
import threading

import numpy as np
import pytest

import teleop
from tests.test_damped_ik import make_dls, WristFK, Q
from tests.test_realman_safe_controller import _controller, _feedback
from tests.test_motion_diagnostics import _row
import xrobotoolkit_teleop.hardware.experiment_recording as recording
from xrobotoolkit_teleop.hardware.experiment_recording import ExperimentSession, summarize, seal_manifest
from xrobotoolkit_teleop.hardware.motion_diagnostics import MotionLog


@pytest.fixture(autouse=True)
def local_only(monkeypatch):
    monkeypatch.setattr(recording, "code_identity", lambda: {"source_sha256": {"fake.py": "fixture"}})


def rows(path, kind):
    return [row for row in recording.read_rows(path) if row.get("type") == kind]


def test_session_seals_metadata_console_events_and_checksums(tmp_path):
    session = ExperimentSession(tmp_path, {"dry_run": True, "control_rate_hz": 50}, note="沿 +z 缓慢移动")
    with session.capture_console():
        print("startup fixture")
        session.event("manual_marker", note="看到抖动", source="operator")
        session.record({**_row(1, session.metadata["started_monotonic_s"]), "grip_active": True})
        session.update_metadata(controller_dh_reply={"joint_1": [1, 2, 3, 4]})
    session.finish("interrupted")
    directory = session.directory
    metadata = json.loads((directory / "session.json").read_text(encoding="utf-8"))
    assert metadata["status"] == "closed" and metadata["outcome"] == "interrupted"
    assert metadata["controller_dh_reply"]["joint_1"] == [1, 2, 3, 4]
    assert "startup fixture" in (directory / "console.log").read_text()
    assert "看到抖动" in (directory / "summary.md").read_text(encoding="utf-8")
    assert summarize(directory)["complete"]
    for name, info in json.loads((directory / "files.json").read_text())["files"].items():
        assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == info["sha256"]
    with pytest.raises(FileExistsError):
        ExperimentSession(tmp_path, {}, session_id=session.session_id)


def test_low_rate_log_is_flushed_before_shutdown(tmp_path):
    log = MotionLog(str(tmp_path / "timed.jsonl"), flush_interval_s=0.02)
    flushed = threading.Event()
    stream = log._file

    class ObservedFile:
        def write(self, value):
            return stream.write(value)

        def flush(self):
            stream.flush()
            flushed.set()

        def close(self):
            stream.close()

    log._file = ObservedFile()
    try:
        log.record(_row(1, 1.0))
        assert flushed.wait(1.0), "one row must flush without waiting for the 500-row batch"
        assert rows(tmp_path / "timed.jsonl", "cycle")
    finally:
        log.close()


def test_control_and_latest_feedback_are_distinct_coherent_frames(tmp_path, monkeypatch):
    session = ExperimentSession(tmp_path, {"dry_run": True})
    original = _feedback()
    latest = replace(
        _feedback(1.01),
        joint_rad=np.ones(6) * 0.1,
        joint_speed_rad_s=np.ones(6) * 0.02,
        tcp_xyz_m=np.array([0.4, 0.1, 0.6]),
        arm_error_codes=(9,),
    )
    c, arm, receiver = _controller(original, motion_log=session, monotonic_fn=lambda: 1.02)
    snapshots = iter([original, latest])
    monkeypatch.setattr(receiver, "latest", lambda: next(snapshots))
    c._run_cycle(1.02)
    session.finish()
    row = rows(session.directory / "motion.jsonl", "cycle")[0]
    assert row["feedback_control"]["joint_rad"] == original.joint_rad.tolist()
    assert row["feedback_latest"]["joint_rad"] == latest.joint_rad.tolist()
    assert row["feedback_latest"]["joint_speed_rad_s"] == latest.joint_speed_rad_s.tolist()
    assert row["feedback_latest"]["arm_error_codes"] == [9]
    assert row["measured_tcp_xyz_m"] == latest.tcp_xyz_m.tolist()
    assert row["feedback_age_s"] == pytest.approx(0.01)
    assert row["feedback_control"]["sample_id"] != row["feedback_latest"]["sample_id"]
    assert row["command_xyz"] is None and row["joint_accepted_rad"] is None
    assert row["motion_send_attempted"] is False
    assert not arm.fault_latched  # merely observing a newer fault frame does not run a new guard


@pytest.mark.parametrize("case", ["tracking", "dead_servo", "overspeed", "stale", "send_failure"])
def test_recording_preserves_differential_ik_targets_holds_and_latches(tmp_path, monkeypatch, case):
    def replay(session=None):
        clock = [1.0]
        c, arm, receiver = make_dls(motion_log=session, monotonic_fn=lambda: clock[0])
        c.grip_active = True
        outcomes = []

        def cycle(now):
            if c._rearm_required:
                return
            target = receiver.feedback.joint_rad.copy()
            target[0] += 0.04
            xyz, quat = WristFK().forward(target)
            quat = np.asarray(quat)
            c._record_target(xyz, quat)
            outcomes.append(c._send_motion(xyz, quat, receiver.feedback.joint_rad))

        monkeypatch.setattr(c, "_run_teleop_cycle", cycle)
        if case == "send_failure":
            arm.send_movej_follow_joint_rad = lambda *a, **k: False
        for index in range(60):
            clock[0] = 1 + index * 0.02
            if case == "tracking" and arm.movej_follow_commands:
                q = arm.movej_follow_commands[-1].copy()
                xyz, quat = WristFK().forward(q)
                quat = np.asarray(quat)
                receiver.feedback = replace(receiver.feedback, joint_rad=q, tcp_xyz_m=xyz, tcp_quat_wxyz=quat)
            stamp = 1.0 if case == "stale" else clock[0]
            speed = np.ones(6) if case == "overspeed" else np.zeros(6)
            receiver.feedback = replace(receiver.feedback, received_monotonic_s=stamp, joint_speed_rad_s=speed)
            c._run_cycle(clock[0])
        return c, arm, outcomes

    baseline, baseline_arm, expected = replay()
    session = ExperimentSession(tmp_path, {"dry_run": False})
    actual, actual_arm, observed = replay(session)
    session.finish()
    assert observed == expected
    assert actual_arm.fault_latched == baseline_arm.fault_latched
    assert actual_arm.fault_reason == baseline_arm.fault_reason
    assert actual_arm.slow_stop_calls == baseline_arm.slow_stop_calls
    assert actual._rearm_required == baseline._rearm_required
    assert len(actual_arm.movej_follow_commands) == len(baseline_arm.movej_follow_commands)
    for left, right in zip(actual_arm.movej_follow_commands, baseline_arm.movej_follow_commands):
        np.testing.assert_array_equal(left, right)
    trace = rows(session.directory / "motion.jsonl", "cycle")
    assert len(trace) == 60
    accepted = [row for row in trace if row["joint_target_accepted"]]
    assert len(accepted) == len(actual_arm.movej_follow_commands)
    for row, command in zip(accepted, actual_arm.movej_follow_commands):
        assert row["joint_accepted_rad"] == command.tolist()
        assert row["joint_sent_rad"] == command.tolist()
    for row in trace:
        if row["hold_active"] or row["state_after"] == "rearm":
            assert row["joint_accepted_rad"] is None
    if case == "dead_servo":
        assert any(row["hold_active"] for row in trace)
        assert any(row["event"] == "hold_enter" for row in rows(session.directory / "events.jsonl", "event"))


def test_startup_exception_is_recorded_before_any_control_cycle(tmp_path, monkeypatch):
    import scripts.hardware.teleop_realman_rm65_safe_hardware as entry

    def fail(**kwargs):
        assert (tmp_path / "startup" / "session.json").is_file()
        raise RuntimeError("SDK fixture missing")

    monkeypatch.setattr(entry, "RealmanRM65SafeTeleopController", fail)
    with pytest.raises(RuntimeError, match="SDK fixture"):
        entry.main(record_root=str(tmp_path), session_id="startup", dry_run=True)
    metadata = json.loads((tmp_path / "startup" / "session.json").read_text(encoding="utf-8"))
    assert metadata["outcome"] == "startup_error"
    assert "SDK fixture missing" in metadata["controller_error"]
    assert "SDK fixture missing" in (tmp_path / "startup" / "console.log").read_text(encoding="utf-8")
    assert rows(tmp_path / "startup" / "motion.jsonl", "cycle") == []


def test_queue_overflow_and_disk_failure_do_not_raise_from_session_close(tmp_path, monkeypatch):
    for failure in ("overflow", "disk"):
        session = ExperimentSession(tmp_path, {"dry_run": True})
        if failure == "overflow":
            with monkeypatch.context() as patch:
                patch.setattr(session.log._queue, "put_nowait", lambda value: (_ for _ in ()).throw(queue.Full()))
                session.record(_row(1, 1.0))
        else:
            stream = session.log._file

            class BrokenFile:
                def write(self, value):
                    raise OSError("fixture disk full")

                def close(self):
                    stream.close()

            session.log._file = BrokenFile()
            session.record(_row(1, 1.0))
        session.finish()
        assert session.error is not None
        assert not summarize(session.directory)["complete"]
        assert json.loads((session.directory / "session.json").read_text())["status"] == "incomplete"


def test_truncated_record_retains_good_rows_and_marks_summary_incomplete(tmp_path):
    session = ExperimentSession(tmp_path, {"dry_run": True})
    session.record(_row(1, 1.0))
    session.finish()
    path = session.directory / "motion.jsonl"
    good = path.read_text().splitlines()[0]
    path.write_text(good + '\n{"type":"cycle",', encoding="utf-8")
    report = summarize(session.directory)
    assert report["counts"]["cycles"] == 1
    assert report["counts"]["invalid_motion_rows"] == 1
    assert not report["complete"]


def test_grip_summary_uses_path_length_for_out_and_back_motion(tmp_path):
    session = ExperimentSession(tmp_path, {"dry_run": True})
    start = session.metadata["started_monotonic_s"]
    for index, x in enumerate((0.0, 0.01, 0.0), 1):
        session.record(
            {
                **_row(index, start + index * 0.02),
                "grip_active": True,
                "xr_pose_used": True,
                "xr_pose": [x, 0, 0, 0, 0, 0, 1],
                "target_xyz": [x, 0, 0],
                "measured_tcp_xyz_m": [x * 0.5, 0, 0],
            }
        )
    session.finish()
    text = (session.directory / "summary.md").read_text(encoding="utf-8")
    assert "20.000 | [0.0, 0.0, 0.0]" in text
    assert "10.000 | [0.0, 0.0, 0.0]" in text


def test_legacy_motion_path_remains_live_and_is_copied_to_archive(tmp_path):
    legacy = tmp_path / "legacy" / "trace.jsonl"
    session = ExperimentSession(tmp_path / "runs", {"dry_run": True}, motion_path=str(legacy))
    assert legacy.exists()
    session.record(_row(1, 1.0))
    session.finish()
    assert legacy.read_bytes() == (session.directory / "motion.jsonl").read_bytes()
    with pytest.raises(FileExistsError):
        ExperimentSession(tmp_path / "runs", {}, motion_path=str(legacy))


def test_state_events_survive_full_cycle_queue(tmp_path, monkeypatch):
    session = ExperimentSession(tmp_path, {"dry_run": True})
    with monkeypatch.context() as patch:
        patch.setattr(session.log._queue, "put_nowait", lambda value: (_ for _ in ()).throw(queue.Full()))
        session.record(_row(1, 1.0))
        session.event("fault_latched", reason="fixture")
    session.finish()
    assert any(row["event"] == "fault_latched" for row in rows(session.directory / "events.jsonl", "event"))
    assert session.metadata["dropped_first_monotonic"] is not None
    assert not summarize(session.directory)["complete"]


def test_stop_observation_preserves_acknowledgement_and_errors(monkeypatch):
    from xrobotoolkit_teleop.hardware.interface.realman_rm65 import RealmanRM65Interface

    arm = RealmanRM65Interface()
    events = []
    arm.diagnostic_event_callback = lambda kind, **details: events.append((kind, details))
    monkeypatch.setattr(arm, "send_json", lambda *a, **k: [{"command": "set_arm_slow_stop", "arm_slow_stop": True}])
    assert arm.slow_stop()
    assert events[-1][1]["acknowledged"] is True
    monkeypatch.setattr(arm, "send_json", lambda *a, **k: [])
    assert not arm.stop()
    assert events[-1][1]["acknowledged"] is False

    def failed(*args, **kwargs):
        raise OSError("fixture transport error")

    monkeypatch.setattr(arm, "send_json", failed)
    with pytest.raises(OSError, match="fixture transport error"):
        arm.stop()
    assert events[-1][0] == "stop_failed"


@pytest.mark.parametrize("value", ["../escape", "x/y", "x;touch hacked", "", "a" * 97])
def test_invalid_session_id_rejected_before_shell(value):
    with pytest.raises(ValueError):
        recording.validate_session_id(value)


def test_launcher_quotes_note_and_preserves_record_toggle(tmp_path, monkeypatch):
    seen, collected = [], []
    monkeypatch.setattr(teleop, "LOCAL_PATH", str(tmp_path))
    monkeypatch.setattr(teleop.sys.stdin, "isatty", lambda: False)
    monkeypatch.setattr(teleop, "collect_recording", lambda value: collected.append(value))

    class Process:
        returncode = 0

        def wait(self):
            return 0

    monkeypatch.setattr(teleop.subprocess, "Popen", lambda command: seen.append(command) or Process())
    note = "沿 z 测试 '引号'; $(fixture)"
    teleop.run_in_container("hardware-dry-run", experiment_note=note)
    bash_script = shlex.split(seen[-1][-1])[-1]
    arguments = shlex.split(bash_script)
    assert arguments[arguments.index("--experiment-note") + 1] == note
    assert len(collected) == 1
    teleop.run_in_container("hardware", record_experiment=False)
    assert "--no-record-experiment" in seen[-1][-1]
    assert len(collected) == 1


@pytest.mark.parametrize("corrupt", [False, True])
def test_retrieval_verifies_checksum_and_retains_failed_attempt(tmp_path, monkeypatch, corrupt):
    session = ExperimentSession(tmp_path / "source", {"dry_run": True}, session_id="fixture_run")
    session.finish()
    commands = []
    monkeypatch.setattr(teleop, "LOCAL_PATH", str(tmp_path / "local"))

    def run(command, **kwargs):
        commands.append(command)
        if command[1] == "-r":
            import shutil

            stage = Path(command[-1])
            for path in session.directory.iterdir():
                shutil.copyfile(path, stage / path.name)
            if corrupt:
                (stage / "motion.jsonl").write_text("changed", encoding="utf-8")
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(teleop.subprocess, "run", run)
    assert teleop.collect_recording("fixture_run") is not corrupt
    root = tmp_path / "local" / "build" / "experiments"
    if corrupt:
        assert not (root / "fixture_run").exists()
        status = json.loads(next(root.glob(".fetch_*/retrieval.json")).read_text(encoding="utf-8"))
        assert not status["verified"] and "校验失败" in status["error"]
    else:
        assert json.loads((root / "fixture_run" / "retrieval.json").read_text())["verified"]
    assert "docker cp" in commands[1][-1]


def test_retrieval_command_does_not_launch_or_sync(monkeypatch):
    monkeypatch.setattr(teleop.sys, "argv", ["teleop.py", "--fetch-recording", "fixture"])
    monkeypatch.setattr(teleop, "sync_code", lambda: pytest.fail("fetch must not synchronize"))
    monkeypatch.setattr(teleop, "run_in_container", lambda *a, **k: pytest.fail("fetch must not start hardware"))
    monkeypatch.setattr(teleop, "collect_recording", lambda value: value == "fixture")
    with pytest.raises(SystemExit) as exc:
        teleop.main()
    assert exc.value.code == 0
