"""Opt-in, bounded asynchronous motion tracing. No disk I/O in record()."""

from collections import deque
import json
import math
from pathlib import Path
import queue
import threading
import time

import numpy as np


def _json_safe(value):
    """Retain fault rows with non-finite sensor values as JSON null."""
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def interval_summary(values):
    values = np.asarray(values, dtype=float) * 1000.0
    return {
        "count": int(values.size),
        **{f"p{q}_ms": float(np.percentile(values, q)) if values.size else None for q in (50, 95, 99)},
        "max_ms": float(np.max(values)) if values.size else None,
        "over_30_ms": int(np.count_nonzero(values > 30.0)),
    }


class MotionStreamStats:
    """Windowed observed rates, not network arrival rates or controller execution."""

    def __init__(self):
        self.send_intervals = deque(maxlen=4096)
        self.transport_intervals = deque(maxlen=4096)
        self.xr_intervals = deque(maxlen=4096)
        self.send_durations = deque(maxlen=4096)
        self.feedback_ages = deque(maxlen=4096)
        self.xr_seconds = {}
        self.xr_changes = deque()
        self.last_send = None
        self.last_transport = None
        self.last_xr_time = None
        self.last_xr_stamp = None
        self.previous_cycle = None

    def observe(self, row):
        now = row["t_monotonic"]
        contiguous = self.previous_cycle is not None and row["cycle_index"] == self.previous_cycle + 1
        self.previous_cycle = row["cycle_index"]
        duration = row.get("send_duration_s")
        age = row.get("feedback_age_s")
        if duration is not None and math.isfinite(duration):
            self.send_durations.append(duration)
        if age is not None and math.isfinite(age):
            self.feedback_ages.append(age)
        second = math.floor(now)
        self.xr_seconds.setdefault(second, 0)
        for old_second in list(self.xr_seconds):
            if old_second < second - 5:
                del self.xr_seconds[old_second]
        send = row.get("send_started_monotonic")
        transport = row.get("transport") or {}
        wire = transport.get("started_monotonic") if transport.get("sendall_completed") else None
        for value, previous, intervals in (
            (send, self.last_send, self.send_intervals),
            (wire, self.last_transport, self.transport_intervals),
        ):
            if contiguous and value is not None and previous is not None:
                intervals.append(value - previous)
        # Idle, failed or skipped sends break segments; intentional pauses are not holes.
        self.last_send, self.last_transport = send, wire
        stamp = row.get("xr_timestamp_ns")
        if stamp is not None and stamp > 0 and stamp != self.last_xr_stamp:
            if self.last_xr_time is not None:
                self.xr_intervals.append(now - self.last_xr_time)
            self.last_xr_time, self.last_xr_stamp = now, stamp
            self.xr_changes.append(now)
            self.xr_seconds[second] += 1
        while self.xr_changes and self.xr_changes[0] <= now - 1.0:
            self.xr_changes.popleft()

    def summary(self):
        result = {
            "send_attempt_interval": interval_summary(self.send_intervals),
            "sendall_interval": interval_summary(self.transport_intervals),
            "xr_observed_interval": interval_summary(self.xr_intervals),
            "xr_changes_last_second": len(self.xr_changes),
            "xr_changes_per_monotonic_second": dict(self.xr_seconds),
            "send_duration": interval_summary(self.send_durations),
            "feedback_age": interval_summary(self.feedback_ages),
        }
        self.send_intervals.clear()
        self.transport_intervals.clear()
        self.xr_intervals.clear()
        self.send_durations.clear()
        self.feedback_ages.clear()
        return result


class MotionLog:
    """Bounded queue and timed flush; all serialization and file writes stay in the worker."""

    def __init__(self, path: str, *, queue_size=10000, event_path=None, console_path=None, flush_interval_s=0.5):
        if queue_size <= 0:
            raise ValueError("queue_size must be positive")
        if not math.isfinite(flush_interval_s) or flush_interval_s <= 0:
            raise ValueError("flush_interval_s must be positive")
        log_path = Path(path)
        # 父目录不存在就先建出来：否则现场一条 `/workspace/logs/xxx.jsonl` 会让程序在
        # **启动阶段**直接 `FileNotFoundError` —— 那跟控制链毫无关系，却会让人以为
        # 「一加日志就启动不了」。文件本身的独占创建（`open("x")`）语义不变。
        log_path.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive creation preserves earlier evidence and validates path before motion.
        self._file = log_path.open("x", encoding="utf-8", buffering=1024 * 1024)
        self._event_file = None
        self._console_file = None
        try:
            if event_path is not None:
                self._event_file = Path(event_path).open("x", encoding="utf-8")
            if console_path is not None:
                self._console_file = Path(console_path).open("x", encoding="utf-8")
        except Exception:
            for stream in (self._file, self._event_file, self._console_file):
                if stream is not None:
                    stream.close()
            raise
        self._flush_interval_s = flush_interval_s
        self._queue = queue.Queue(maxsize=queue_size)
        # State/stop evidence has its own bounded capacity; console/cycle bursts cannot consume it.
        self._event_queue = queue.Queue(maxsize=max(128, min(1000, queue_size)))
        self.dropped_rows = 0
        self.dropped_first_monotonic = None
        self.dropped_last_monotonic = None
        self.error = None
        self._closed = False
        self._thread = threading.Thread(target=self._worker, name="rm65-motion-log", daemon=True)
        self._thread.start()

    def _enqueue(self, item, *, event=False):
        if self._closed:
            raise RuntimeError("motion log is closed")
        try:
            (self._event_queue if event else self._queue).put_nowait(item)
        except queue.Full:
            self.dropped_rows += 1
            now = time.monotonic()
            if self.dropped_first_monotonic is None:
                self.dropped_first_monotonic = now
            self.dropped_last_monotonic = now

    def record(self, row):
        self._enqueue(("cycle", row))

    def summary(self, counters):
        self._enqueue(("summary", counters))

    def event(self, row, **details):
        if isinstance(row, str):
            row = {"type": "event", "event": row, **details}
        self._enqueue(("event", row), event=True)

    def console(self, value):
        self._enqueue(("console", value))

    def _worker(self):
        stats = MotionStreamStats()
        batch = []
        events = []
        console = []
        last_flush = time.monotonic()

        def flush():
            nonlocal last_flush
            if not batch and not events and not console:
                return
            try:
                self._file.write("".join(json.dumps(_json_safe(row), allow_nan=False) + "\n" for row in batch))
                self._file.flush()
                if self._event_file is not None:
                    self._event_file.write(
                        "".join(json.dumps(_json_safe(row), allow_nan=False) + "\n" for row in events)
                    )
                    self._event_file.flush()
                if self._console_file is not None:
                    self._console_file.write("".join(console))
                    self._console_file.flush()
            except Exception as exc:
                self.error = str(exc)
            batch.clear()
            events.clear()
            console.clear()
            last_flush = time.monotonic()

        while True:
            try:
                try:
                    item = self._event_queue.get_nowait()
                except queue.Empty:
                    item = self._queue.get(timeout=max(0.001, self._flush_interval_s - (time.monotonic() - last_flush)))
            except queue.Empty:
                flush()
                last_flush = time.monotonic()
                continue
            if item is None:
                # Sentinel can wake a get() that began before the event was enqueued.
                while True:
                    try:
                        _, row = self._event_queue.get_nowait()
                        events.append(row)
                    except queue.Empty:
                        break
                break
            kind, row = item
            if kind == "cycle":
                try:
                    stats.observe(row)
                except Exception as exc:
                    self.error = f"motion statistics: {exc}"
                batch.append(row)
            elif kind == "event":
                events.append(row)
            elif kind == "console":
                console.append(row)
            elif kind == "summary":
                summary = {
                    "type": "summary",
                    **row,
                    **stats.summary(),
                    "log_dropped_rows": self.dropped_rows,
                    "log_error": self.error,
                }
                batch.append(summary)
                # Only this worker prints new periodic diagnostics, never the control loop.
                try:
                    print("[MOTION TIMING] " + json.dumps(summary, allow_nan=False))
                except Exception as exc:
                    self.error = str(exc)
            if (
                len(batch) + len(events) + len(console) >= 500
                or time.monotonic() - last_flush >= self._flush_interval_s
            ):
                flush()
        batch.append({"type": "log_end", "dropped_rows": self.dropped_rows, "error": self.error})
        events.append({"type": "log_end", "dropped_rows": self.dropped_rows, "error": self.error})
        flush()
        for stream in (self._file, self._event_file, self._console_file):
            if stream is not None:
                try:
                    stream.close()
                except Exception as exc:
                    self.error = str(exc)

    def close(self):
        if not self._closed:
            self._closed = True
            self._queue.put(None, timeout=5.0)
            self._thread.join(timeout=5.0)
            if self._thread.is_alive():
                raise RuntimeError("motion log did not drain within 5 seconds; trace may be incomplete")
            if self.error or self.dropped_rows:
                raise RuntimeError(f"incomplete motion log: error={self.error}, dropped={self.dropped_rows}")
