"""Experiment evidence around the existing control trace; no robot/SDK queries here."""

from collections import Counter, deque
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import select
import subprocess
import sys
import threading
import time
import uuid

import numpy as np

from .motion_diagnostics import MotionLog, _json_safe, interval_summary
from xrobotoolkit_teleop.utils.code_fingerprint import repository_root, source_hashes

BEIJING = timezone(timedelta(hours=8))
SESSION_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,95}\Z")


def new_session_id():
    return datetime.now(BEIJING).strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]


def validate_session_id(value):
    if not SESSION_ID_PATTERN.fullmatch(value):
        raise ValueError("session_id must contain only letters, numbers, underscores and hyphens (1–96 characters)")
    return value


def _write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(_json_safe(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def code_identity():
    root = repository_root()
    hashes = source_hashes(root)
    for relative in (
        "xrobotoolkit_teleop/hardware/motion_diagnostics.py",
        "xrobotoolkit_teleop/hardware/experiment_recording.py",
        "xrobotoolkit_teleop/utils/geometry.py",
        "xrobotoolkit_teleop/hardware/rm65_model.py",
    ):
        hashes[relative] = hashlib.sha256((root / relative).read_bytes()).hexdigest()
    result = {"source_sha256": hashes, "git_commit": None, "git_dirty": None}
    try:
        commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, timeout=2)
        status = subprocess.run(["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, timeout=2)
        if commit.returncode == 0:
            result["git_commit"] = commit.stdout.strip()
        if status.returncode == 0:
            result["git_dirty"] = bool(status.stdout.strip())
    except (OSError, subprocess.SubprocessError):
        pass
    return result


def _packages():
    result = {"python": sys.version}
    for name in ("numpy", "Robotic_Arm", "xrobotoolkit-sdk"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = None
    return result


def read_rows(path):
    """Streaming reader that retains complete rows from a truncated/aborted run."""
    if not path.exists():
        return
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError("row is not an object")
                yield row
            except (ValueError, TypeError) as exc:
                yield {"type": "invalid_row", "line": line_number, "error": str(exc)}


def summarize(directory):
    """Rebuildable Markdown summary; log completeness is separate from robot acceptance."""
    directory = Path(directory)
    metadata = json.loads((directory / "session.json").read_text(encoding="utf-8"))
    counts = Counter()
    holds = Counter()
    tails = {}
    segments = []
    segment = None
    previous_cycle = None
    last_feedback_id = None
    periods, elapsed, feedback_ages = (deque(maxlen=4096) for _ in range(3))

    def observe_position(layer, value):
        if value is None:
            return
        vector = np.asarray(value, dtype=float)
        if vector.shape != (3,) or not np.all(np.isfinite(vector)):
            return
        state = segment["layers"].setdefault(layer, {"start": vector, "last": vector, "path": 0.0, "samples": 0})
        state["path"] += float(np.linalg.norm(vector - state["last"]))
        state["last"] = vector
        state["samples"] += 1

    for row in read_rows(directory / "motion.jsonl"):
        kind = row.get("type")
        if kind == "log_end":
            tails["motion"] = row
        elif kind == "invalid_row":
            counts["invalid_motion_rows"] += 1
        elif kind == "cycle":
            if not isinstance(row.get("cycle_index"), int) or not isinstance(row.get("t_monotonic"), (int, float)):
                counts["invalid_motion_rows"] += 1
                continue
            counts["cycles"] += 1
            index = row["cycle_index"]
            if previous_cycle is not None and index != previous_cycle + 1:
                counts["cycle_gaps"] += 1
            previous_cycle = index
            counts["accepted_joint_targets"] += row.get("joint_target_accepted") is True
            counts["send_attempts"] += row.get("motion_send_attempted") is True
            counts["sendall_completed"] += (row.get("transport") or {}).get("sendall_completed") is True
            counts["deadline_overruns"] += row.get("cycle_overrun") is True
            for key, collection in (
                ("cycle_period_s", periods),
                ("cycle_elapsed_s", elapsed),
                ("feedback_age_s", feedback_ages),
            ):
                value = row.get(key)
                if isinstance(value, (float, int)) and np.isfinite(value) and value >= 0:
                    collection.append(value)
            feedback = row.get("feedback_latest") or {}
            sample_id = feedback.get("sample_id")
            if sample_id is not None:
                counts["reused_feedback_cycles"] += sample_id == last_feedback_id
                last_feedback_id = sample_id
            counts["stale_feedback_cycles"] += (row.get("feedback_age_s") or 0) > metadata["configuration"].get(
                "udp_feedback_timeout_s", 0.2
            )
            if row.get("hold_active"):
                holds[row.get("hold_reason") or "unspecified"] += 1
            if row.get("grip_active") and segment is None:
                segment = {"start": row["t_monotonic"], "end": row["t_monotonic"], "cycles": 0, "layers": {}}
            if segment is not None:
                segment["end"] = row["t_monotonic"]
                segment["cycles"] += 1
                if row.get("xr_pose_used") and row.get("xr_pose") is not None:
                    observe_position("XR 原始位置", row["xr_pose"][:3])
                observe_position("映射目标", row.get("target_xyz"))
                observe_position("限速候选", row.get("command_xyz"))
                if row.get("joint_target_accepted"):
                    observe_position("接受目标 TCP（已有 FK）", row.get("dls_achieved_xyz"))
                observe_position("UDP 实测 TCP", row.get("measured_tcp_xyz_m"))
                if not row.get("grip_active"):
                    segments.append(segment)
                    segment = None
    if segment is not None:
        segments.append(segment)
    event_counts = Counter()
    markers = []
    for row in read_rows(directory / "events.jsonl"):
        if row.get("type") == "log_end":
            tails["events"] = row
        elif row.get("type") == "invalid_row":
            counts["invalid_event_rows"] += 1
        elif row.get("type") == "event":
            event_counts[row.get("event")] += 1
            if row.get("event") == "manual_marker":
                markers.append(row)
    complete = (
        metadata.get("status") == "closed"
        and metadata.get("recording_error") is None
        and len(tails) == 2
        and all(not tail.get("error") and tail.get("dropped_rows") == 0 for tail in tails.values())
        and not any(counts[key] for key in ("cycle_gaps", "invalid_motion_rows", "invalid_event_rows"))
    )
    report = {"complete": complete, "counts": dict(counts), "events": dict(event_counts), "holds": dict(holds)}
    timing = {
        "period": interval_summary(periods),
        "cycle_elapsed": interval_summary(elapsed),
        "feedback_age": interval_summary(feedback_ages),
    }
    report["timing_last_4096_samples"] = timing
    duration = metadata.get("duration_s")
    text = [
        "# RM65 实验记录",
        "",
        f"- 实验：`{metadata['session_id']}`",
        f"- 备注：{metadata.get('note') or '未填写'}",
        f"- 模式：{'Dry Run' if metadata['configuration'].get('dry_run') else '真机'}",
        f"- 开始：{metadata['started_at']}",
        f"- 时长：{duration:.2f} s" if duration is not None else "- 时长：结束时间未知",
        f"- 退出：{metadata.get('outcome', '未知（未正常封存）')}",
        f"- 控制异常：{metadata.get('controller_error') or '无记录'}",
        f"- 记录异常：{metadata.get('recording_error') or '无记录'}",
        f"- 记录完整性：{'完整' if complete else '不完整，需查看 session.json 和 log_end'}",
        "",
        "记录完整不表示真机验收通过。sendall_completed 仅证明本机 socket 写入完成，不证明机械臂执行。",
        "",
        "## 控制周期",
        "",
    ]
    text += [f"- {key}: {value}" for key, value in counts.items()]
    hold_count = sum(holds.values())
    text += [
        f"- 保持周期占比：{hold_count / counts['cycles']:.1%}" if counts["cycles"] else "- 保持周期占比：无周期数据",
        "",
        "时序分位数采用末尾最多 4096 个有效样本：",
        "",
        "| 量 | p50 / ms | p95 / ms | p99 / ms | max / ms |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for label, values in timing.items():
        cells = [
            f"{values[key]:.3f}" if values[key] is not None else "无样本"
            for key in ("p50_ms", "p95_ms", "p99_ms", "max_ms")
        ]
        text.append(f"| {label} | " + " | ".join(cells) + " |")
    text += ["", "## Grip 段", "", "| 段 | 起点（相对开始 / s） | 时长 / s | 周期 |", "| --- | ---: | ---: | ---: |"]
    origin = metadata["started_monotonic_s"]
    for i, data in enumerate(segments, 1):
        text.append(f"| {i} | {data['start'] - origin:.3f} | {data['end'] - data['start']:.3f} | {data['cycles']} |")
    for i, data in enumerate(segments, 1):
        text += [
            "",
            f"### 第 {i} 段运动",
            "",
            "| 数据层 | 有效点 | 路程 / mm | 净位移 XYZ / mm |",
            "| --- | ---: | ---: | --- |",
        ]
        for layer, state in data["layers"].items():
            displacement = np.round((state["last"] - state["start"]) * 1000, 3).tolist()
            travel = f"{state['path'] * 1000:.3f}" if state["samples"] >= 2 else "证据不足"
            text.append(f"| {layer} | {state['samples']} | {travel} | {displacement} |")
    text += ["", "各数据层使用自己的有效点计算路程，不做无激励或往返运动的净位移比判定；XR 方向处于原始 SDK 坐标系。"]
    text += ["", "## 自动事件", ""] + [f"- {name}: {count}" for name, count in event_counts.items()]
    text += ["", "## 保持原因（周期数）", ""] + [f"- {reason}: {count}" for reason, count in holds.items()]
    text += ["", "## 人工标记", ""] + [
        f"- {row['t_monotonic'] - origin:.3f} s：{row.get('note') or '观察到异常'}" for row in markers
    ]
    text += ["", "数据单位：m、rad、rad/s；XR 原始四元数 XYZW，其余四元数 WXYZ。", ""]
    (directory / "summary.md").write_text("\n".join(text), encoding="utf-8")
    return report


def seal_manifest(directory):
    directory = Path(directory)
    files = {}
    for name in ("session.json", "motion.jsonl", "events.jsonl", "console.log", "summary.md"):
        path = directory / name
        if path.is_file():
            digest = hashlib.sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
            files[name] = {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}
    _write_json(directory / "files.json", {"version": 1, "files": files})


class _ConsoleTee:
    def __init__(self, original, session):
        self.original, self.session = original, session

    def write(self, value):
        self.session.console(value)
        return self.original.write(value)

    def flush(self):
        self.original.flush()

    def __getattr__(self, name):
        return getattr(self.original, name)


class ExperimentSession:
    """MotionLog protocol adapter. Logging failure is evidence loss, never a motion decision."""

    def __init__(self, root, configuration, *, note="", session_id="", motion_path="", queue_size=10000):
        self.session_id = validate_session_id(session_id or new_session_id())
        self.directory = Path(root).resolve() / self.session_id
        self.directory.mkdir(parents=True, exist_ok=False)
        self.error = None
        self._closed = False
        self._finished = False
        self._event_index = 0
        self._event_lock = threading.Lock()
        self._marker_stop = threading.Event()
        self._marker_thread = None
        self._terminal_settings = None
        self.motion_path = Path(motion_path).resolve() if motion_path else None
        self.metadata = {
            "schema_version": 1,
            "session_id": self.session_id,
            "note": note,
            "started_at": datetime.now(BEIJING).isoformat(),
            "started_monotonic_s": time.monotonic(),
            "status": "running",
            "configuration": configuration,
            "code": code_identity(),
            "packages": _packages(),
            "units": {
                "position": "m",
                "joint": "rad",
                "joint_speed": "rad/s",
                "xr_quaternion": "xyzw",
                "quaternion": "wxyz",
            },
            "clock": "host monotonic; XR device timestamp is not synchronized to it",
            "field_semantics": {
                "target_xyz": "mapped target before Cartesian limiter",
                "command_xyz": "limited candidate, possibly rejected",
                "joint_accepted_rad": "accepted this cycle; null on hold/rejection/no solve",
                "joint_sent_rad": "argument submitted to the motion send method; wire_json contains actual quantized payload",
                "transport": "actual serialized motion payload and socket outcome; not execution acknowledgement",
                "feedback_control": "last checked UDP frame in this cycle; feedback_for_ik is the solver input frame",
                "feedback_latest": "single UDP snapshot observed at cycle end; repeated timestamp means same sample",
            },
        }
        _write_json(self.directory / "session.json", self.metadata)
        try:
            self.log = MotionLog(
                str(self.motion_path or self.directory / "motion.jsonl"),
                queue_size=queue_size,
                event_path=self.directory / "events.jsonl",
                console_path=self.directory / "console.log",
            )
        except Exception as exc:
            self.metadata.update(status="incomplete", recording_error=str(exc))
            _write_json(self.directory / "session.json", self.metadata)
            raise
        # Explicit legacy path is the live trace; the archive copy is made only after draining.
        self.event("session_started")

    def record(self, row):
        if not self._closed:
            self.log.record(row)

    def summary(self, counters):
        if not self._closed:
            self.log.summary(counters)

    def console(self, value):
        if value and not self._closed:
            self.log.console(value)

    def event(self, kind, *, t_monotonic=None, **details):
        if self._closed:
            return
        with self._event_lock:
            self._event_index += 1
            self.log.event(
                {
                    "type": "event",
                    "event": kind,
                    "event_index": self._event_index,
                    "t_monotonic": time.monotonic() if t_monotonic is None else t_monotonic,
                    **details,
                }
            )
        if kind == "control_loop_started":
            self._start_markers()

    def update_metadata(self, **details):
        self.metadata.update(details)
        # Called during startup, outside the periodic controller loop.
        _write_json(self.directory / "session.json", self.metadata)

    def _start_markers(self):
        if self._marker_thread is not None or not sys.stdin.isatty():
            return
        try:
            if os.name != "nt":
                import termios
                import tty

                self._terminal_settings = (sys.stdin.fileno(), termios.tcgetattr(sys.stdin))
                tty.setcbreak(sys.stdin.fileno())
            self._marker_thread = threading.Thread(target=self._markers, name="rm65-experiment-markers", daemon=True)
            self._marker_thread.start()
            print("[RECORD] 已自动记录；按 m 仅添加观察标记，Ctrl+C 结束。")
        except (OSError, ValueError) as exc:
            self.event("marker_unavailable", reason=str(exc))

    def _markers(self):
        try:
            while not self._marker_stop.wait(0.05):
                value = ""
                if os.name == "nt":
                    import msvcrt

                    if msvcrt.kbhit():
                        value = msvcrt.getwch()
                elif select.select([sys.stdin], [], [], 0)[0]:
                    value = os.read(sys.stdin.fileno(), 1).decode("utf-8", errors="ignore")
                    if not value:
                        break
                if value.lower() == "m":
                    self.event("manual_marker", note="操作员按 m 标记观察现象", source="keyboard")
        except (OSError, ValueError) as exc:
            self.event("marker_unavailable", reason=str(exc))

    @contextmanager
    def capture_console(self):
        original_out, original_err = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = _ConsoleTee(original_out, self), _ConsoleTee(original_err, self)
        try:
            print(f"[RECORD] session={self.session_id} directory={self.directory}")
            yield self
        finally:
            sys.stdout, sys.stderr = original_out, original_err

    def close(self):
        if self._closed:
            return
        self._marker_stop.set()
        if self._marker_thread is not None:
            self._marker_thread.join(timeout=0.5)
        if self._terminal_settings is not None:
            import termios

            fd, settings = self._terminal_settings
            try:
                termios.tcsetattr(fd, termios.TCSADRAIN, settings)
            except OSError:
                pass
        self.event("recording_closing")
        self._closed = True
        try:
            self.log.close()
        except Exception as exc:
            self.error = str(exc)

    def finish(self, outcome="returned", error=None):
        if self._finished:
            return
        self.close()
        self._finished = True
        self.metadata.update(
            status="closed" if self.error is None else "incomplete",
            ended_at=datetime.now(BEIJING).isoformat(),
            ended_monotonic_s=time.monotonic(),
            duration_s=time.monotonic() - self.metadata["started_monotonic_s"],
            outcome=outcome,
            controller_error=error,
            recording_error=self.error,
            dropped_rows=self.log.dropped_rows,
            dropped_first_monotonic=self.log.dropped_first_monotonic,
            dropped_last_monotonic=self.log.dropped_last_monotonic,
            writer_error=self.log.error,
        )
        _write_json(self.directory / "session.json", self.metadata)
        if self.log._thread.is_alive():
            # Never hash/download a trace while a stuck writer can still change it.
            print(f"[RECORD ERROR] 写线程尚未退出；目录保留、未封存：{self.directory}")
            return
        if self.motion_path is not None:
            with (self.directory / "motion.jsonl").open("xb") as destination, self.motion_path.open("rb") as source:
                import shutil

                shutil.copyfileobj(source, destination)
        report = summarize(self.directory)
        seal_manifest(self.directory)
        print(f"[RECORD] {'完整' if report['complete'] else '不完整'}；摘要：{self.directory / 'summary.md'}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Rebuild a summary from a closed or interrupted experiment")
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(summarize(args.directory), ensure_ascii=False))
    seal_manifest(args.directory)
