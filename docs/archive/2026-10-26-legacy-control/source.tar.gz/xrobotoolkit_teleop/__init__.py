# Apply once at import when running in Docker (MESHCAT_HOST_PORT is set).
from xrobotoolkit_teleop.utils.meshcat_utils import patch_placo_meshcat_host

patch_placo_meshcat_host()
"""Retired implementation; the supported runtime is rm65_servo_teleop."""

raise RuntimeError(
    "The former Python IK/teleoperation stack is retired. Use python teleop.py --mode sim "
    "for the ROS2 MoveIt Servo stack. No legacy-controller fallback is available."
)
